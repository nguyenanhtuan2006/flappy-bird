using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CharacterSelectUI : MonoBehaviour
{
    public Image previewImage;
    public TMPro.TextMeshProUGUI characterNameText;
    private CharacterData currentSelection;

    public void OnCharacterButtonClicked(CharacterData data)
    {
        currentSelection = data;
        previewImage.sprite = data.previewSprite;
        characterNameText.text = data.characterName;
    }

    public void OnPlayButtonClicked()
    {
        if (currentSelection == null) return; // Nếu chưa chọn ai thì không cho chơi
        GameSelectionManager.Instance.selectedCharacter = currentSelection;
        
        
        SceneManager.LoadScene("kobt"); 
    }
}