using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSelectUI : MonoBehaviour 
{
    private LevelData currentSelectedLevel; // Lưu level đang chọn trên UI

    // Gọi hàm này khi bấm vào 1 ô Level trong danh sách
    public void OnSelectLevel(LevelData data) 
    {
        currentSelectedLevel = data;
        // Cập nhật UI Preview (Tên màn, icon, số sao...) tại đây
    }

    // Gắn hàm này vào sự kiện OnClick của Nút PLAY
    public void OnPlayButton() 
    {
        if (currentSelectedLevel == null) return;

        // Lưu dữ liệu level được chọn sang Manager
        GameSelectionManager.Instance.selectedLevel = currentSelectedLevel;

        // Chuyển sang GameScene
        SceneManager.LoadScene("GameScene");
    }
}