using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab; // Prefab quái tạo ở Bước 1
    public EnemyData[] enemyTypes; // Các loại EnemyData (Gà con, Gà to...)
    public float spawnInterval = 2f; // Thời gian ra 1 con quái

    private float timer;

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= spawnInterval)
        {
            timer = 0f;
            SpawnEnemy();
        }
    }

    void SpawnEnemy()
    {
        // Tạo vị trí ngẫu nhiên ở mép trên màn hình
        Vector3 spawnPos = new Vector3(Random.Range(-2f, 2f), 6f, 0f);
        
        // Sinh ra quái
        GameObject newEnemy = Instantiate(enemyPrefab, spawnPos, Quaternion.identity);
        
        // Gán ngẫu nhiên 1 loại dữ liệu EnemyData cho quái vừa tạo
        if (enemyTypes.Length > 0)
        {
            EnemyData randomData = enemyTypes[Random.Range(0, enemyTypes.Length)];
            newEnemy.GetComponent<Enemy>().data = randomData;
        }
    }
}