using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro; 

public class Bird : MonoBehaviour 
{
    private Rigidbody2D rigidbody;  
    public float jumpForce;
    public GameObject gameController;
    public GameObject message;
    private bool levelStart;
    private int score;
    public TextMeshProUGUI scoreText;

    // Animation
    public Sprite[] sprites; 
    private SpriteRenderer spriteRenderer;
    private int spriteIndex;

    //BIẾN ĐỔI NỀN
    public SpriteRenderer backgroundRenderer; 
    public Sprite daySprite;                  
    public Sprite nightSprite;                
    private bool isDay = true;                

   private void Awake()
    {
      rigidbody = this.gameObject.GetComponent<Rigidbody2D>();
      levelStart = false;
      rigidbody.gravityScale = 0;
      score = 0;
      scoreText.text = score.ToString();   
      message.GetComponent<SpriteRenderer>().enabled = true; 

      spriteRenderer = GetComponent<SpriteRenderer>();

      // --- Lấy dữ liệu nhân vật đã chọn từ Scene Menu ---
      if (GameSelectionManager.Instance != null && GameSelectionManager.Instance.selectedCharacter != null)
      {
          CharacterData chosenData = GameSelectionManager.Instance.selectedCharacter;
          
        
          spriteRenderer.sprite = chosenData.previewSprite; 
          
          // Gán danh sách ảnh chuyển động đập cánh
          this.sprites = chosenData.flapAnimation;

          // Tắt Animator cũ (nếu có) để không bị đè hình Chim mặc định lên nhân vật mới
          if (GetComponent<Animator>() != null) 
          {
              GetComponent<Animator>().enabled = false; 
          }
      }

      InvokeRepeating(nameof(AnimateSprite), 0.15f, 0.15f); 
    }

    void Update()
    {
     if (Keyboard.current.spaceKey.wasPressedThisFrame )
        { 
             SoundController.instance.PlayThisSound("wing", 1.5f);
          if(levelStart == false)
            {
                levelStart = true ;
                rigidbody.gravityScale = 6;
                gameController.GetComponent<PipeGenerator>().enableGenratePipe = true;
                message.GetComponent<SpriteRenderer>().enabled = false ;
            }
           BirdMoveUp();
        }
    }

    private void BirdMoveUp()
    {
        rigidbody.linearVelocity = Vector2.up * jumpForce;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    { 
         SoundController.instance.PlayThisSound("hit", 0.5f);
         StartCoroutine(DelayAndReload()); 
    }

    private IEnumerator DelayAndReload()
    {
         yield return new WaitForSeconds(0.5f); 
         SceneManager.LoadScene("kobt");
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        SoundController.instance.PlayThisSound("point", 0.5f);
        score += 1;
        scoreText.text = score.ToString();     

        // XỬ LÝ ĐỔI NỀN
        if (score > 0 && score % 5 == 0) 
        {
            isDay = !isDay; 
            backgroundRenderer.sprite = isDay ? daySprite : nightSprite;
        }
    }

    private void AnimateSprite()
    {
        if (sprites == null || sprites.Length == 0) return; 

        spriteIndex++;
        if (spriteIndex >= sprites.Length) {
            spriteIndex = 0; 
        }
        spriteRenderer.sprite = sprites[spriteIndex];
    }
}