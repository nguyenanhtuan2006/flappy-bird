using UnityEngine;
using System.Collections.Generic;
using System.Collections;
 public class PipeGenerator : MonoBehaviour
{
    public GameObject pipePrefab; 
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private float countdown;
    public float timeDuration;
    public bool enableGenratePipe; //cho phep sinh ra ong 
    private void Awake()
  {
    countdown = 1f;
    enableGenratePipe = false;
  }
    // Update is called once per frame
    void Update() // 
    {
       if(enableGenratePipe == true)
       {
         countdown -= Time.deltaTime;
        if(countdown <= 0 )
         {
           //sinh ra ong 
            Instantiate(pipePrefab, new Vector3(-0.3f, Random.Range(-1.22f, 2.51f),0), Quaternion.identity);
           countdown = timeDuration; 
          }
         }
     }
}
