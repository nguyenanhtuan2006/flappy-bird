using UnityEngine;

[CreateAssetMenu(fileName = "NewLevel", menuName = "ShootGame/Level")]
public class LevelData : ScriptableObject
{
    public string levelName;
    public Sprite levelIcon;          // Icon trong lưới chọn màn
    public Sprite backgroundSprite;
    public WaveData[] waves;          // Các đợt địch trong màn này
    public int starRequirement;       // Điểm để mở khóa (nếu muốn)
    public bool isLocked;
}

[System.Serializable]
public class WaveData
{
    public EnemySpawnInfo[] enemies;
    public float delayBeforeWave = 1f;
}

[System.Serializable]
public class EnemySpawnInfo
{
    public EnemyData enemyType;
    public Vector2 spawnPosition;
    public float spawnDelay;
}

