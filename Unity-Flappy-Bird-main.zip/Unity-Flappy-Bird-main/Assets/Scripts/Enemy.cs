using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
    public EnemyData data;
    private int currentHP;
    private float fireTimer;
    private Transform player;
    private float moveTimer;
    private Vector3 startPos;

    void Start()
    {
        if (data != null) currentHP = data.maxHP;
        startPos = transform.position;

        GameObject p = GameObject.FindGameObjectWithTag("Player");
        if (p != null) player = p.transform;

        if (GetComponent<SpriteRenderer>() != null && data != null)
            GetComponent<SpriteRenderer>().sprite = data.sprite;
    }

    void Update()
    {
        if (data == null) return;

        Move();
        fireTimer += Time.deltaTime;
        if (fireTimer >= data.fireRate)
        {
            fireTimer = 0f;
            Attack();
        }
    }

    void Move()
    {
        moveTimer += Time.deltaTime;
        switch (data.movePattern)
        {
            case MovePattern.Straight:
                transform.position += Vector3.down * data.moveSpeed * Time.deltaTime;
                break;
            case MovePattern.ZigZag:
                transform.position += new Vector3(Mathf.Sign(Mathf.Sin(moveTimer * 3f)) * data.moveSpeed, -data.moveSpeed, 0) * Time.deltaTime;
                break;
            case MovePattern.Sine:
                transform.position = startPos + new Vector3(Mathf.Sin(moveTimer * 2f) * 2f, -moveTimer * data.moveSpeed, 0);
                break;
            case MovePattern.Circle:
                float angle = moveTimer * data.moveSpeed;
                transform.position = startPos + new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0) * 1.5f;
                break;
            case MovePattern.Dive:
                if (player != null)
                {
                    Vector3 dir = (player.position - transform.position).normalized;
                    transform.position += dir * data.moveSpeed * Time.deltaTime;
                }
                break;
            case MovePattern.Stationary:
                break;
        }
    }

    void Attack()
    {
        switch (data.attackPattern)
        {
            case AttackPattern.SingleShot:
                SpawnBullet(Vector2.down);
                break;
            case AttackPattern.Spread3:
                SpawnBullet(Quaternion.Euler(0, 0, -20) * Vector2.down);
                SpawnBullet(Vector2.down);
                SpawnBullet(Quaternion.Euler(0, 0, 20) * Vector2.down);
                break;
            case AttackPattern.Spread5:
                for (int i = -2; i <= 2; i++)
                    SpawnBullet(Quaternion.Euler(0, 0, i * 15) * Vector2.down);
                break;
            case AttackPattern.AimedShot:
                if (player != null)
                    SpawnBullet((player.position - transform.position).normalized);
                break;
            case AttackPattern.Burst:
                StartCoroutine(BurstFire());
                break;
            case AttackPattern.Circular:
                for (int i = 0; i < 12; i++)
                    SpawnBullet(Quaternion.Euler(0, 0, i * 30) * Vector2.down);
                break;
            case AttackPattern.Laser:
                break;
        }
    }

    IEnumerator BurstFire()
    {
        for (int i = 0; i < 3; i++)
        {
            if (player != null)
                SpawnBullet((player.position - transform.position).normalized);
            yield return new WaitForSeconds(0.15f);
        }
    }

    void SpawnBullet(Vector2 direction)
    {
        if (data == null || data.bulletPrefab == null) return;
        GameObject b = Instantiate(data.bulletPrefab, transform.position, Quaternion.identity);
        if (b.TryGetComponent<Bullet>(out Bullet bullet))
        {
            bullet.SetDirection(direction);
        }
    }

    public void TakeDamage(int dmg)
    {
        currentHP -= dmg;
        if (currentHP <= 0) Die();
    }

    void Die()
{
    // Tạm thời comment dòng này nếu chưa tạo GameManager
    // if (GameManager.Instance != null && data != null) GameManager.Instance.AddScore(data.scoreValue);

    if (data != null && data.dropItemPrefab != null)
    {
        Instantiate(data.dropItemPrefab, transform.position, Quaternion.identity);
    }

    Destroy(gameObject);
}
}