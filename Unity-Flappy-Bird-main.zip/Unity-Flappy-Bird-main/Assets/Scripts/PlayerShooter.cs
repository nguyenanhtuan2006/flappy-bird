using UnityEngine;

public class PlayerShooter : MonoBehaviour
{
    public GameObject milkBulletPrefab; // Prefab đạn sữa
    public Transform[] firePoints;       // Các nòng bắn (1 hoặc nhiều điểm)
    public float fireRate = 0.2f;        // Tốc độ bắn (giây/viên)
    private float timer;

    void Update()
    {
        timer += Time.deltaTime;
        if (Input.GetKey(KeyCode.Space) && timer >= fireRate)
        {
            timer = 0f;
            foreach (var point in firePoints)
            {
                GameObject bullet = Instantiate(milkBulletPrefab, point.position, Quaternion.identity);
                if (bullet.TryGetComponent<Bullet>(out Bullet b))
                {
                    b.SetDirection(Vector2.up); // Bắn hướng lên trên
                }
            }
        }
    }
}