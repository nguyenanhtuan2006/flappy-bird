using UnityEngine;

[CreateAssetMenu(fileName = "NewCharacter", menuName = "FlappyBird/Character")]
public class CharacterData : ScriptableObject
{
    public string characterName;
    public Sprite selectIcon;
    public Sprite previewSprite;
    public Sprite[] flapAnimation; // Mảng chứa 3 ảnh đập cánh
}   