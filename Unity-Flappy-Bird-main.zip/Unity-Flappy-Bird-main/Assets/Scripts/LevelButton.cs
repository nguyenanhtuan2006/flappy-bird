using UnityEngine;
using UnityEngine.UI;

public class LevelButton : MonoBehaviour
{
    public LevelData levelData;
    private LevelSelectUI selectUI;

    public void Init(LevelData data, LevelSelectUI ui)
    {
        levelData = data;
        selectUI = ui;
        // Có thể gán icon/tên lên nút tại đây nếu muốn
    }

    // Gán hàm này vào Event OnClick của chính Button này
    public void OnClickButton()
    {
        selectUI.OnSelectLevel(levelData);
    }
}