using UnityEngine;
[CreateAssetMenu(fileName = "NewEnemy", menuName = "ShootGame/Enemy")]
public class EnemyData : ScriptableObject
{
    public string enemyName;
    public Sprite sprite;
    public int maxHP;
    public float moveSpeed;
    public MovePattern movePattern;
    public AttackPattern attackPattern;
    public GameObject bulletPrefab;
    public float fireRate;
    public int scoreValue;
    public GameObject dropItemPrefab; // rơi vật phẩm khi chết (không bắt buộc)
}

public enum MovePattern
{
    Straight,       // bay thẳng xuống
    ZigZag,         // bay hình chữ Z
    Sine,           // bay hình sóng sin
    Circle,         // bay vòng tròn quanh 1 điểm
    Dive,           // lao thẳng vào người chơi
    Stationary      // đứng yên 1 chỗ (kiểu turret)
}

public enum AttackPattern
{
    SingleShot,     // bắn 1 viên thẳng
    Spread3,        // bắn 3 viên tỏa hình quạt
    Spread5,        // bắn 5 viên tỏa rộng
    AimedShot,      // bắn nhắm thẳng vào người chơi
    Burst,          // bắn liên tiếp 3-4 phát nhanh rồi nghỉ
    Circular,       // bắn vòng tròn 360 độ
    Laser           // bắn tia laser kéo dài (né bằng cách di chuyển)
}