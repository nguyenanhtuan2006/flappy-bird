using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 8f;
    public int damage = 1;
    public bool isPlayerBullet; // Tích chọn nếu là đạn sữa của Player
    private Vector2 direction;

    public void SetDirection(Vector2 dir) => direction = dir.normalized;

    void Update()
    {
        transform.Translate(direction * speed * Time.deltaTime);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Đạn sữa trúng Quái
        if (isPlayerBullet && other.CompareTag("Enemy"))
        {
            if (other.TryGetComponent<Enemy>(out Enemy enemy))
            {
                enemy.TakeDamage(damage);
            }
            Destroy(gameObject);
        }
        // Đạn Quái trúng Player
        else if (!isPlayerBullet && other.CompareTag("Player"))
        {
         //   if (other.TryGetComponent<PlayerHealth>(out PlayerHealth health))
            {
           //     health.TakeDamage(damage);
            }
            Destroy(gameObject);
        }
    }
}