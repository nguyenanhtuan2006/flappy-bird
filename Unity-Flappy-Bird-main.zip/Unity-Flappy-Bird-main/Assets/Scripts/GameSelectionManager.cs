using UnityEngine;

public class GameSelectionManager : MonoBehaviour
{
    public static GameSelectionManager Instance;
    public CharacterData selectedCharacter; // Lưu nhân vật đang chọn
    public LevelData selectedLevel;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // Lệnh quan trọng: Không xóa vật thể này khi chuyển Scene
        }
        else
        {
            Destroy(gameObject);
        }
    }
}